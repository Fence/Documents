# -*- coding: utf-8 -*-

from deep_ocr.utils import trim_string

data = u'''
一二三四
'''

data = trim_string(data)
