# -*- coding: utf-8 -*-

from deep_ocr.utils import trim_string

data = u'''
0123456789
'''

data = trim_string(data)
