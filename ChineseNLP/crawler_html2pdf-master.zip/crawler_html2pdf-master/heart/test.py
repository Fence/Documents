# -*- coding:utf-8 -*-
import jieba

print " ".join(jieba.cut(u"::	[AVI/329M][C0930-hitozuma1007] 坂井雪恵 Yukie Sakai  (308123)"))