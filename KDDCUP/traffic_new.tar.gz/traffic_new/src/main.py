import os
import json
import argparse
import numpy as np
from regression import regression
from evalutor import LabelEvalutor
from preprocess import DataSet
from extract_feature import extract_feature

path = '../data/dataSets/training/'
suffix = '.json'

def main():
	in_file = 'trajectories(table 5)_training'
	weather_file = 'weather(table 7)_training'
	
	import ipdb
	ipdb.set_trace()
	
	train_file = 'train_data' + suffix
	dev_file = 'dev_data' + suffix
	shared_file = 'shared_data' + suffix
	
	# train_file = 'train_data_partial' + suffix
	# dev_file = 'dev_data_partial' + suffix
	# shared_file = 'shared_data_partial' + suffix

	# train_file = 'train_data_partial_6_8_15_17' + suffix
	# dev_file = 'dev_data_partial_6_8_15_17' + suffix
	# shared_file = 'shared_data_partial_6_8_15_17' + suffix
	# train_file = 'train_data_plus_route_length' + suffix
	# dev_file = 'dev_data_plus_route_length' + suffix
	train_file = 'train_data_plus_route_length_and_width' + suffix
	dev_file = 'dev_data_plus_route_length_and_width' + suffix

	train_file = 'train_data_plus_route_length_and_width_plus_last_next_day' + suffix
	dev_file = 'dev_data_plus_route_length_and_width_plus_last_next_day' + suffix

	if os.path.exists(path + train_file):
		with open(path + train_file, 'r') as fh:
			train_data = json.load(fh)
	if os.path.exists(path + dev_file):
		with open(path + dev_file, 'r') as fh:
			dev_data = json.load(fh)
	if os.path.exists(path + shared_file):
		with open(path + shared_file) as fh:
			shared_data = json.load(fh)

	train_data_set = DataSet(train_data, shared_data, 'train')
	dev_data_set = DataSet(dev_data, shared_data, 'dev')


	args = get_args()
	reg = regression(args, train_data_set)

	validation_X, validation_Y, object_avg_tt, object_avg_tt_max, object_avg_tt_min = extract_feature(dev_data_set)
	Y_ = reg.predict(validation_X)

	print 'max_value %f' % object_avg_tt_max
	print 'min_value %f' % object_avg_tt_min
	predicted_object_avg_tt = get_predicted_object_avg_tt(Y_, object_avg_tt_max, object_avg_tt_min)
	e = LabelEvalutor(validation_X, validation_Y, Y_, object_avg_tt, predicted_object_avg_tt)
	mape = e.MAPE
	print mape
	# e.print_designated_format()

def get_predicted_object_avg_tt(rate, object_avg_tt_max, object_avg_tt_min):
	assert object_avg_tt_max > object_avg_tt_min
	interval_width = object_avg_tt_max - object_avg_tt_min
	delta = np.multiply(rate, interval_width)
	out = np.add(object_avg_tt_min, delta)
	return out

def get_args():
	parser = argparse.ArgumentParser()
	parser.add_argument("--model", default="svm", help="designated model will be used to do regression")
	# argparser.add_argument()
	args = parser.parse_args()
	return args

def print_designated_format():
	pass
if __name__ == '__main__':
	main()