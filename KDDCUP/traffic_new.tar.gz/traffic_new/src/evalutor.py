import math
import numpy as np

class Evalutor(object):
	"""docstring for evalutor"""
	def __init__(self, X, Y):
		super(Evalutor, self).__init__()
		self.X = X
		self.Y = Y

class LabelEvalutor(Evalutor):
	"""docstring for LabelEvalutor"""
	def __init__(self, X, Y, Yp, avt_tt, predicted_avg_tt):
		super(LabelEvalutor, self).__init__(X, Y)
		self.Yp = Yp
		self.avt_tt = np.squeeze(avt_tt)
		self.predicted_avg_tt = predicted_avg_tt
		difference = self.avt_tt - self.predicted_avg_tt
		import ipdb
		ipdb.set_trace()

		#print avt_tt[:100]
		#print difference[:100]
		difference = Y - Yp
		result = np.concatenate((Y, Yp, difference), -1)
		#result = np.concatenate((avt_tt, np.expand_dims(predicted_avg_tt, -1), np.expand_dims(difference, -1)), -1)
		#print result
		#print predicted_avg_tt[:20]
		#print predicted_avg_tt
		self.get_MAPE()
	
	def get_MAPE(self):
		rate = np.absolute(1 - np.divide(self.avt_tt, self.predicted_avg_tt))
		mape = np.mean(rate)
		self.MAPE = mape
	
	def get_evaluator(self):	
		return Evalutor(X, Y)
