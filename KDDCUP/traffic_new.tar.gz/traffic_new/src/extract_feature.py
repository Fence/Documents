import os
import json
import re
import numpy as np

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2, f_regression, mutual_info_regression
from sklearn.preprocessing import normalize as sk_normalize
from sklearn.preprocessing import Imputer, robust_scale
from utils import encode
from preprocess import DataSet

VERY_LARGE_NUMBER = 1e30

path = '../data/dataSets/training/'

def log_normalize(data):
	width = len(data)
	out = map(lambda item: map(lambda x: np.log(x), item), data)
	return out

def linear_normalize(data):
	out = []
	width = len(data[0])
	max_value = [0.0] * width
	min_value = [VERY_LARGE_NUMBER] * width
	for j in range(width):
		for i in range(len(data)):
			if data[i][j] > max_value[j]:
				max_value[j] = data[i][j]
			if data[i][j] < min_value[j]:
				min_value[j] = data[i][j]

	interval_width = map(lambda x, y: x - y, max_value, min_value)
	# interval_width = [lambda x, y: x - y for x, y in zip(max_value, min_value)]
	for i in range(len(data)):
		out.append(map(lambda x, y, z: (x - y) / z, data[i], min_value, interval_width))
		#for j in range(width):
		#	data[i][j] = (data[i][j] - min_value[j]) / interval_width[j]
	return out

def normalize(data, key, normalize_type=None):
	# data :list or 2D list
	normalize_type = 'linear_normalization' if normalize_type==None else 'log_normalization'
	if normalize_type == 'log_normalization':
		out = log_normalize(data)
		# out = linear_normalize(res)
	elif normalize_type == 'linear_normalization':
		out = linear_normalize(data)
	else:
		raise ValueError("invalid normalize_type")
	return out

def get_object_avg_tt_span(avg_tt):
	object_avg_tt_min = VERY_LARGE_NUMBER
	object_avg_tt_max = 0
	for item in avg_tt:
		if object_avg_tt_max < item[0]:
			object_avg_tt_max = item[0]
		if object_avg_tt_min > item[0]:
			object_avg_tt_min = item[0]

	return object_avg_tt_max, object_avg_tt_min

def extract_feature(data_set):
	assert isinstance(data_set, DataSet)
	data = data_set.data
	shared = data_set.shared
	route_num = len(shared)
	transformed_data = {}
	X = []
	Y = []
	X_combined = []
	# extract feature
	# print data_set.data.keys()
	# import ipdb
	# ipdb.set_trace()
	avg_tt = data[data_set.data_type+'_object_avg_tt']
	object_avg_tt_max, object_avg_tt_min = get_object_avg_tt_span(data[data_set.data_type+'_object_avg_tt'])
	# true_data = reduce(lambda x, y: np.concatenate((np.array(x),np.array(y)), -1), [data[key] for key in data.keys() if key.endswith('weather') or key.endswith('consecutive_interval') or key.endswith('route') or key.endswith('object_interval')])
	
	# normalize data
	print data.keys()
	for key in data.keys():
		#print key, key
		#import ipdb
		#ipdb.set_trace()
		if isinstance(data[key][0], list) and not key.endswith('object_avg_tt'):
		# if isinstance(data[key][0], float) or isinstance(data[key][0], int) or instance(data[key], list):
		# if type(data[key][0]) == 'float' or type(data[key][0]) == 'int' or type(data[key][0][0]) == 'float' or type(data[key][0][0]) == 'int':
			#data[key] = robust_scale(np.array(data[key]))
			#imputer = Imputer(missing_values='NaN', strategy='mean', axis=0)
			#data[key] = imputer.fit(data[key])
			#data[key] = imputer.transform(data[key])
			#data[key] = sk_normalize(np.array(data[key]))
			data[key] = normalize(data[key], key, normalize_type=None)

	for key in data.keys():
		if key.endswith('interval'):
			#if key.endswith('object_interval'):
			#	object_interval = [encode(item) for item in data[key]]
			#	object_interval = np.array(object_interval)
			#	transformed_data[key] = object_interval

			pass
			# object_interval = [encode(item) for item in data[key]]
			# object_interval = np.array(object_interval)
			# transformed_data[key] = object_interval

		elif key.endswith('route'):
			pass
			#transformed_data[key] = np.array(data[key])
			
			#route2idx = shared['route2idx']
			#depth = len(shared['route2idx'])
			#transformed_data[key] = [route2idx[item] for item in data[key]]
			#transformed_data[key] = convertToOneHot(np.array(transformed_data[key]), num_classes=depth)

			# print data[key].shape
			# data[key] = [np.put(np.zeros(depth, dtype='float'), route2idx[item], 1.0) for item in data[key]]

		elif key.endswith('object_avg_tt'):
			pass
		elif key.endswith('sum_avg_tt'):
			pass
		else:
			transformed_data[key] = np.array(data[key])


	# combine each two features
	data_keys = transformed_data.keys()
	print data_keys
	data_keys.sort()
	print data_keys
	for i in range(len(data_keys)):
		j = i + 1
		#item = np.log(transformed_data[data_keys[i]])
		#X_combined.append(item)
		while j < len(data_keys):
			item = np.concatenate((transformed_data[data_keys[i]], transformed_data[data_keys[j]]), -1)
			X_combined.append(item)
			j = j + 1

	X_combined = reduce(lambda x, y:np.concatenate((x, y), -1), X_combined)
	X = reduce(lambda x, y: np.concatenate((x, y), -1), [transformed_data[key] for key in data_keys])
	X = np.concatenate((X, X_combined), -1)

	# X = reduce(lambda x, y: np.concatenate((x, y), -1), [data[key] for key in data.keys() if not key.endswith('_object_avg_tt') and not key.endswith('interval') and not key.endswith('route')])
	# X = reduce(lambda x, y: np.concatenate((x, y), -1), [transformed_data[key] for key in transformed_data.keys() if not key.endswith('interval')])
	# X = reduce(lambda x,y: np.concatenate((x, y), -1), [transformed_data[key] for key in transformed_data.keys() if not key.endswith('_object_avt_tt')])
	# X = reduce(lambda x,y: np.concatenate((x, y), -1), [transformed_data[key] for key in transformed_data.keys() if not key.endswith('_object_avt_tt') and not key.endswith('first_interval') and not key.endswith('last_interval')])
	# X = reduce(lambda x, y: np.concatenate((x, y), -1), [transformed_data[key] for key in transformed_data.keys() if not key.endswith('_object_avg_tt') and not key.endswith('interval')])
	# X = reduce(lambda x, y: np.concatenate((x, y), -1), [transformed_data[key] for key in transformed_data.keys() if not key.endswith('last_interval') and not key.endswith('first_interval') and not key.endswith('object_interval')])
	Y = data[data_set.data_type+ '_object_avg_tt']
	X = np.array(X)
	Y = np.squeeze(np.array(Y))

	# feature selection
	
	#X_new = SelectKBest(f_regression, k=10).fit_transform(X, Y)
	X_new = X
	return X_new, Y, np.array(avg_tt), object_avg_tt_max, object_avg_tt_min

def convertToOneHot(vector, num_classes=None):
    """
    Converts an input 1-D vector of integers into an output
    2-D array of one-hot vectors, where an i'th input value
    of j will set a '1' in the i'th row, j'th column of the
    output array.

    Example:
        v = np.array((1, 0, 4))
        one_hot_v = convertToOneHot(v)
        print one_hot_v

        [[0 1 0 0 0]
         [1 0 0 0 0]
         [0 0 0 0 1]]
    """

    assert isinstance(vector, np.ndarray)
    assert len(vector) > 0

    if num_classes is None:
        num_classes = np.max(vector)+1
    else:
        assert num_classes > 0
        assert num_classes >= np.max(vector)

    result = np.zeros(shape=(len(vector), num_classes))
    result[np.arange(len(vector)), vector] = 1
    return result.astype(int)

def main():
	import ipdb
	ipdb.set_trace()
	suffix = '.json'
	train_file = 'train_data' + suffix
	dev_file = 'dev_data' + suffix
	if os.path.exists(path + train_file):
		with open(path + train_file ,'r') as fh:
			train_data = json.load(fh)
	if os.path.exists(path + dev_file):
		with open(path + dev_file, 'r') as fh:
			dev_data = json.load(fh)

	train_data = DataSet(train_data, 'train')
	dev_data = DataSet(dev_data, 'dev')
	X, Y = extract_feature(train_data)

if __name__ == '__main__':
	main()

