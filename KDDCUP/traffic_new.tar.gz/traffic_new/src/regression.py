import os
import json
import numpy as np
from sklearn import linear_model
from sklearn import svm
from sklearn import gaussian_process as gp
from sklearn import kernel_ridge as kr
from sklearn.neighbors import NearestNeighbors as nn
from sklearn.neighbors import KNeighborsRegressor
from sklearn.multioutput import MultiOutputRegressor
import matplotlib.pyplot as plt

from preprocess import preprocess, DataSet
from extract_feature import extract_feature

def regression(args, data_set):
	X, Y, _, _, _ = extract_feature(data_set)
	if args.model == 'lr':
		reg = MultiOutputRegressor(linear_model.LinearRegression())
	elif args.model == 'svm':
		#reg = svm.SVR()
		# reg = svm.NuSVR()
		reg = MultiOutputRegressor(svm.LinearSVR())
	elif args.model == 'lasso':
		reg = MultiOutputRegressor(linear_model.Lasso())
	elif args.model == 'ridge':
		reg = linear_model.Ridge(alpha=.5)
	elif args.model == 'gpr':
		reg = gp.GaussianProcessRegressor()
	elif args.model == 'krr':
		reg = kr.KernelRidge()
	elif args.model == 'nn':
		reg = KNeighborsRegressor()
	else:
		raise ValueError('invalid model')
	reg.fit(X, Y)
	return reg

if __name__ == '__main__':
	pass
	# regression()
