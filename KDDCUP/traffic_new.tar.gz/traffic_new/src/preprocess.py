from datetime import datetime, timedelta
import math
import json
from collections import Counter
from utils import convert_to_interval_number, partial, encode

file_suffix = '.csv'
path = '../data/dataSets/training/'

class DataSet(object):
	"""docstring for DataSet"""
	def __init__(self, data, shared, data_type):
		super(DataSet, self).__init__()
		self.data = data
		self.shared = shared
		self.data_type = data_type
		self.num = len(data[data.keys()[0]])
		self.valid_idx = range(self.num)
		self.data_consecutive_avg_tt_max = 0
		self.data_consecutive_avg_tt_min = 0
		self.data_sum_avg_tt_max = 0
		self.data_sum_avg_tt_min = 0

	def get_batch(data, batch_size=None, shuffle=False):
		epoch = self.num // batch_size
		shuffle_idx = random.shuffle(self.valid_idx)
		batch_data = {}
		for i in range(epoch):
			idxs = shuffle_idx[batch_size*i : batch_size*(i+1)] if shuffle else self.valid_idx
			for key in self.data.keys():
				batch[key] = [self.data[key][idx] for idx in idxs]
			batch = DataSet(batch_data)
			yield idxs, batch

def preprocess(in_file, weather_file, road_links_dict, route_info_dict):
	in_file_name = in_file + file_suffix
	fr = open(path + in_file_name, 'r')
	fr.readline()
	traj_data = fr.readlines()
	fr.close()

	# traj_data = traj_data[:10000]
	travel_times = {}
	for i in range(len(traj_data)):	
		each_traj = traj_data[i].replace('"', '').split(',')
		intersection_id = each_traj[0]
		tollgate_id = each_traj[1]

		route_id = intersection_id + '-' + tollgate_id
		if route_id not in travel_times.keys():
			travel_times[route_id] = {}

		trace_start_time = each_traj[3]
		trace_start_time = datetime.strptime(trace_start_time, "%Y-%m-%d %H:%M:%S")
		time_window_minute = int(math.floor(trace_start_time.minute / 20) * 20)
		start_time_window = datetime(trace_start_time.year, trace_start_time.month, trace_start_time.day,
									trace_start_time.hour, time_window_minute, 0)

		tt = float(each_traj[-1]) # travel time
		if start_time_window not in travel_times[route_id].keys():
			travel_times[route_id][start_time_window] = [tt]
		else:
			travel_times[route_id][start_time_window].append(tt)

	for route in travel_times.keys():
		route_time_windows = list(travel_times[route].keys())
		route_time_windows.sort()
		for time_window_start in route_time_windows:
			time_window_end = time_window_start + timedelta(minutes=20)
			tt_set = travel_times[route][time_window_start]
			avg_tt = round(sum(tt_set) / float(len(tt_set)), 2)
			travel_times[route][time_window_start] = avg_tt	
	
	weather_file_name = weather_file + file_suffix
	fr = open(path + weather_file_name, 'r')
	fr.readline()
	weather_data = fr.readlines()
	fr.close()

	weather_stat = {}
	for i in range(len(weather_data)):
		each_weather_data = weather_data[i].replace('"', '').split(',')
		date = each_weather_data[0]
		date = datetime.strptime(date, "%Y-%m-%d")
		time = datetime(date.year, date.month, date.day, int(each_weather_data[1]))
		statitics = [float(item) for item in  each_weather_data[2:]]
		weather_stat[time] = statitics
	# date = datetime(2016, 9, 2, 9)

	train_dataset, dev_dataset = construct_dataset(travel_times, weather_stat, road_links_dict, route_info_dict)
	return train_dataset, dev_dataset

def construct_dataset(travel_times, weather_stat, road_links_dict, route_info_dict):
	train_data = {}
	dev_data = {}
	shared_data = {}
	route_counter = Counter()
	# tags for training, 9 tags
	train_route_info = []
	train_first_interval = []
	train_last_interval = []
	train_consecutive_avg_tt = []
	train_sum_avg_tt = []
	train_object_interval = []
	train_object_avg_tt = []
	train_weather = []
	train_object_weather = []
	train_last_next_day = []

	#tags for validation, 9 tags
	dev_route_info = []
	dev_first_interval = []
	dev_last_interval = []
	dev_consecutive_avg_tt = []
	dev_sum_avg_tt = []
	dev_object_interval = []
	dev_object_avg_tt = []
	dev_weather = []
	dev_object_weather = []
	dev_last_next_day = []

	date_flag = datetime(2016, 10, 7)

	for route in travel_times.keys():
		route_counter[route] += 1

		for start_time_window in travel_times[route].keys():
			if start_time_window > date_flag:
				if 6 == start_time_window.hour or 15 == start_time_window.hour:
					avg_tts = []
					first_interval_number = convert_to_interval_number(start_time_window)
					last_interval_number = convert_to_interval_number(start_time_window+timedelta(hours=2)) - 1
					
					year, month, day, hour = start_time_window.year, start_time_window.month, start_time_window.day, start_time_window.hour
					date = datetime(year, month, day, int(hour/3)*3)
					assert date.hour % 3 == 0
					if date not in weather_stat.keys():
						continue
					weather_item = weather_stat[date]
					
					for i in range(6):
						choosed_time = start_time_window+timedelta(minutes=i*20)
						if choosed_time not in travel_times[route].keys():
							continue
						avg_tt = travel_times[route][choosed_time]
						avg_tts.append(avg_tt)
					sum_tt = [sum(avg_tts) / len(avg_tts)]
					avg_tts = avg_tts + sum_tt * (6 - len(avg_tts))
					sum_tt = [sum(avg_tts) / len(avg_tts)]
					
					object_start_window_time = start_time_window+timedelta(hours=2)
					year, month, day, hour = object_start_window_time.year, object_start_window_time.month, object_start_window_time.day, object_start_window_time.hour
					date = datetime(year, month, day, int(hour/3)*3)
					assert date.hour % 3 == 0
					if date not in weather_stat.keys():
						continue
					object_weather_item = weather_stat[date]

					for i in range(6):
						object_start_window_time = object_start_window_time + timedelta(minutes=i*20)
						if object_start_window_time not in travel_times[route].keys():
							continue

						#last_day_avg_tt = travel_times[route][object_start_window_time-timedelta(days=1)] \
						#					if object_start_window_time-timedelta(days=1) in travel_times[route].keys() else travel_times[route][object_start_window_time]
						#next_day_avg_tt = travel_times[route][object_start_window_time+timedelta(days=1)] \
						#					if object_start_window_time+timedelta(days=1) in travel_times[route].keys() else travel_times[route][object_start_window_time]

						avg_tt = [travel_times[route][object_start_window_time]]
						object_interval_number = convert_to_interval_number(object_start_window_time)
						dev_consecutive_avg_tt.append(avg_tts)
						dev_sum_avg_tt.append(sum_tt)
						dev_object_avg_tt.append(avg_tt)
						dev_first_interval.append(first_interval_number)
						dev_last_interval.append(last_interval_number)
						dev_object_interval.append(object_interval_number)
						dev_weather.append(weather_item)
						dev_object_weather.append(object_weather_item)
						dev_route_info.append(get_route_info(route, road_links_dict, route_info_dict))
						#dev_last_next_day.append([last_day_avg_tt, next_day_avg_tt])

			else:
				# if (start_time_window + timedelta(hours=2) in travel_times[route].keys()) and partial(start_time_window):
				if (start_time_window + timedelta(hours=2) in travel_times[route].keys()):
					avg_tts = []
					first_interval_number = convert_to_interval_number(start_time_window)
					last_interval_number = convert_to_interval_number(start_time_window+timedelta(hours=2)) - 1
					
					year, month, day, hour = start_time_window.year, start_time_window.month, start_time_window.day, start_time_window.hour
					date = datetime(year, month, day, int(hour/3)*3)
					assert date.hour % 3 == 0
					if date not in weather_stat.keys():
						continue
					weather_item = weather_stat[date]
					
					for i in range(6):
						choosed_time = start_time_window+timedelta(minutes=i*20)
						if choosed_time not in travel_times[route].keys():
							continue
						avg_tt = travel_times[route][choosed_time]
						avg_tts.append(avg_tt)
					sum_tt = [sum(avg_tts) / len(avg_tts)]
					avg_tts = avg_tts + sum_tt * (6 - len(avg_tts))
					sum_tt = [sum(avg_tts) / len(avg_tts)]
					
					object_start_window_time = start_time_window+timedelta(hours=2)
					year, month, day, hour = object_start_window_time.year, object_start_window_time.month, object_start_window_time.day, object_start_window_time.hour
					date = datetime(year, month, day, int(hour/3)*3)
					assert date.hour % 3 == 0
					if date not in weather_stat.keys():
						continue
					object_weather_item = weather_stat[date]
					
					for i in range(6):
						object_start_window_time = object_start_window_time + timedelta(minutes=i*20)
						if object_start_window_time not in travel_times[route].keys():
							continue

						#last_day_avg_tt = travel_times[route][object_start_window_time-timedelta(days=1)] \
						#					if object_start_window_time-timedelta(days=1) in travel_times[route].keys() else travel_times[route][object_start_window_time]
						#next_day_avg_tt = travel_times[route][object_start_window_time+timedelta(days=1)] \
						#					if object_start_window_time+timedelta(days=1) in travel_times[route].keys() else travel_times[route][object_start_window_time]
						
						avg_tt = [travel_times[route][object_start_window_time]]
						object_interval_number = convert_to_interval_number(object_start_window_time)
						train_consecutive_avg_tt.append(avg_tts)
						train_sum_avg_tt.append(sum_tt)
						train_object_avg_tt.append(avg_tt)
						train_first_interval.append(first_interval_number)
						train_last_interval.append(last_interval_number)
						train_object_interval.append(object_interval_number)
						train_weather.append(weather_item)
						train_object_weather.append(object_weather_item)
						train_route_info.append(get_route_info(route, road_links_dict, route_info_dict))
						#train_last_next_day.append([last_day_avg_tt, next_day_avg_tt])
	
	train_data['train_consecutive_avg_tt'] = train_consecutive_avg_tt
	train_data['train_sum_avg_tt'] = train_sum_avg_tt
	train_data['train_object_avg_tt'] = train_object_avg_tt
	train_data['train_first_interval'] = train_first_interval
	train_data['train_last_interval'] = train_last_interval
	train_data['train_object_interval'] = train_object_interval
	train_data['train_weather'] = train_weather
	train_data['train_object_weather'] = train_object_weather
	train_data['train_route'] = train_route_info
	# train_data['train_last_next_day'] = train_last_next_day

	dev_data['dev_consecutive_avg_tt'] = dev_consecutive_avg_tt
	dev_data['dev_sum_avg_tt'] = dev_sum_avg_tt
	dev_data['dev_object_avg_tt'] = dev_object_avg_tt
	dev_data['dev_first_interval'] = dev_first_interval
	dev_data['dev_last_interval'] = dev_last_interval
	dev_data['dev_object_interval'] = dev_object_interval
	dev_data['dev_weather'] = dev_weather
	dev_data['dev_object_weather'] = dev_object_weather
	dev_data['dev_route'] = dev_route_info
	# dev_data['dev_last_next_day'] = dev_last_next_day

	route2idx = get_route2idx(route_counter)
	shared_data['route2idx'] = route2idx

	# dump into file
	suffix = '.json'
	train_file = 'train_data_plus_route_length_and_width_plus_last_next_day' + suffix
	dev_file = 'dev_data_plus_route_length_and_width_plus_last_next_day' + suffix
	shared_file = 'shared_data' + suffix
	json.dump(train_data, open(path + train_file, 'w'))
	json.dump(dev_data, open(path + dev_file, 'w'))
	json.dump(shared_data, open(path + shared_file, 'w'))
	train_dataset = DataSet(train_data, shared_data, 'train')
	dev_dataset = DataSet(dev_data, shared_data, 'dev')
	return train_dataset, dev_dataset

def get_route_info(route, road_links_dict, route_info_dict):
	route_info = []
	route_length = 0
	route_width = 0
	route_lanes = 0
	route_links = route_info_dict[route]
	for link_id in route_links:
		#route_length += road_links_dict[link_id]['length'] #  * road_links_dict[link_id]['width']
		route_length += road_links_dict[link_id]['length']
		route_width += road_links_dict[link_id]['width']
	#route_lanes = road_links_dict[link_id]['lanes']
	route_info.append(route_length)
	route_info.append(route_width/len(route_links))
	return route_info

def get_route2idx(route_counter):
	route2idx = {}
	route2idx = {route: idx for idx, route in enumerate(route for route, count in route_counter.items())}
	return route2idx

def process_volume_data(infile):
	infile = infile + file_suffix
	fr = open(infile, 'r')
	fr.readline()
	vol_data = fr.readlines()
	fr.close()

	volumes = {}
	for i in range(len(vol_data)):
		each_pass = vol_data[i].replace('"', '').split(',')
		tollgate_id = each_pass[1]
		direction = each_pass[2]

		pass_time = each_pass[0]
		pass_time = datetime.strptime(pass_time, "%Y-%m-%d %H:%M:%S")
		time_window_minute = int(math.floor(pass_time.minute / 20) * 20)
		#print pass_time
		start_time_window = datetime(pass_time.year, pass_time.month, pass_time.day,
									pass_time.hour, time_window_minute, 0)
		
		if start_time_window not in volumes:
			volumes[start_time_window] = {}
		if tollgate_id not in volumes[start_time_window]:
			volumes[start_time_window][tollgate_id] = {}
		if direction not in volumes[start_time_window][tollgate_id]:
			volumes[start_time_window][tollgate_id][direction] = 1
		else:
			volumes[start_time_window][tollgate_id][direction] += 1


	return volumes

def process_route_data(road_link_file, intersection2tollagte_file):
	# import ipdb
	# ipdb.set_trace()
	road_link_file = road_link_file + file_suffix
	intersection2tollagte_file = intersection2tollagte_file + file_suffix
	fr = open(path + road_link_file, 'r')
	fr.readline()
	road_links = fr.readlines()
	fr = open(path + intersection2tollagte_file, 'r')
	fr.readline()
	routes = fr.readlines()

	road_links_dict = {}
	for i in range(len(road_links)):
		road_link = road_links[i].rstrip().replace('"', '').split(',')
		# print road_link
		road_link_id = road_link[0]
		if road_link_id not in road_links_dict:
			road_links_dict[road_link_id] = {}
			road_links_dict[road_link_id]['length'] = float(road_link[1])
			road_links_dict[road_link_id]['width'] = float(road_link[2])
			road_links_dict[road_link_id]['lanes'] = int(road_link[3])
			# road_links_dict[road_link_id]['in_top'] = road_link[4]
			# road_links_dict[road_link_id]['out_top'] = road_link[5]
			road_links_dict[road_link_id]['lane_width'] = float(road_link[-1])

	route_info_dict = {}
	for i in range(len(routes)):
		route = routes[i].rstrip().replace('"', '').split(',')
		intersection_id = route[0]
		tollgate_id = route[1]
		route_id = intersection_id + '-' + tollgate_id
		if route_id not in route_info_dict:
			route_info_dict[route_id] = route[2:]

	return road_links_dict, route_info_dict

def construct_volume_data_set():

	return

def main():
	in_file = 'trajectories(table 5)_training'
	weather_file = 'weather(table 7)_training'
	import ipdb
	ipdb.set_trace()
	
	road_link_file = 'links(table 3)'
	intersection2tollgate_file = 'routes(table 4)'
	road_links_dict, route_info_dict = process_route_data(road_link_file, intersection2tollgate_file)
	print road_links_dict, route_info_dict


	train_data, dev_data = preprocess(in_file, weather_file, road_links_dict, route_info_dict)

if __name__ == '__main__':
	main()