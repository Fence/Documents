import numpy as np

def convert_to_interval_number(datetime):
	return datetime.hour * 3 + datetime.minute / 20

def partial(datetime):
	if (datetime.hour > 6 and datetime.hour < 11) or (datetime.hour > 14 and datetime.hour < 19):
		return True
	return False

def encode(number):
	bit_num = 8
	code = []
	x = number % 2
	i = 0
	while i < bit_num:
		code.append(x)
		number = number // 2
		x = number % 2
		i = i + 1

	return code

if __name__ == '__main__':
	x = 54
	c = encode(x)
	print c