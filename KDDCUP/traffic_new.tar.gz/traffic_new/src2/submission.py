from datetime import datetime, timedelta
import numpy as np
import json
from preprocess import read_data, read_route_data, get_route_info, preprocess
from utils import encode, convert_to_interval_number, convert_to_time_window, type_of_date, one_hot_encode, piecewise_encode
from FeatureExtractor import FeatureExtractor

path_test = '../data/dataSets/testing_phase1/'
suffix = '.csv'
path = '../data/dataSets/training/'


def construct_data(test_trajectory_file, test_weather_file, road_link_file, intersection2tollgate_file, data_file):
	travel_times, weather_stat = read_data(test_trajectory_file, test_weather_file, path=path_test)
	road_links_dict, route_info_dict = read_route_data(road_link_file, intersection2tollgate_file, path=path)

	route_id = []
	time = []
	test_data = {}
	date_type = []
	interval = []
	moment = []
	weather = []
	route_info = []
	object_weather = []
	consecutive_avg_tt = []
	object_consecutive_avg_tt = []

	routes = list(travel_times.keys())
	routes.sort()
	for i in range(len(routes)):
		route = routes[i]
		route_time_windows = list(travel_times[route].keys())
		route_time_windows.sort()
		#partial_route_time_windows = route_time_windows[::6]
		partial_route_time_windows = []
		date = datetime(2016, 10, 18)
		while date < datetime(2016, 10, 25):
			date = date + timedelta(hours=6)
			partial_route_time_windows.append(date)
			date = date + timedelta(hours=9)
			partial_route_time_windows.append(date)
			date = datetime(date.year, date.month, int(date.day+1))

		for i in range(len(partial_route_time_windows)):
			current_time_window = partial_route_time_windows[i]
			c_a_t = []
			for i in range(6):
				if current_time_window + timedelta(minutes=20*i) in route_time_windows:
					c_a_t.append(travel_times[route][current_time_window + timedelta(minutes=20*i)])
				else:
					c_a_t.append(np.NaN)

			time_window_start = current_time_window + timedelta(hours=1)
			year, month, day, hour = time_window_start.year, time_window_start.month, time_window_start.day, time_window_start.hour
			date1 = datetime(year, month, day, int(((hour+1)//3)*3)%24)
			date2 = datetime(year, month, day, int(((hour+3)//3)*3)%24)
			assert date1.hour % 3 == 0
			assert date2.hour % 3 == 0
			weather_item = weather_stat[date1]
			if weather_item[2] >= 360:
				weather_item[2] = np.NaN
			object_weather_item = weather_stat[date2]
			if object_weather_item[2] >= 360:
				object_weather_item[2] = np.NaN
			
			for i in range(6):
				consecutive_avg_tt.append(c_a_t)
				interval.append(one_hot_encode(i, bit_num=6))
				object_consecutive_avg_tt.append([np.NaN])
				route_info.append(get_route_info(route, road_links_dict, route_info_dict))
				weather.append(weather_item)
				object_weather.append(object_weather_item)
				moment.append(piecewise_encode(current_time_window+timedelta(hours=2), bit_num=6))
				route_id.append(route)
				time.append(current_time_window)
				date_type.append(encode(type_of_date(datetime(time_window_start.year, time_window_start.month, time_window_start.day)), bit_num=2))

	test_data['route_info'] = route_info
	test_data['weather'] = weather
	test_data['object_weather'] = object_weather
	test_data['consecutive_avg_tt'] = consecutive_avg_tt
	test_data['object_consecutive_avg_tt'] = object_consecutive_avg_tt
	test_data['moment'] = moment
	test_data['interval'] = interval
	test_data['date_type'] = date_type

	suffix = '.json'
	test_data_file = 'test_data' + suffix
	json.dump(test_data, open(path_test + 'src2_data/' + test_data_file, 'w'))
	return route_id, time

def write_into_file(route_id, time, test_set, predicted_Y, result_file):
	#import ipdb
	#ipdb.set_trace()
	data = test_set.data
	i = 0
	result_file_name = result_file + suffix
	with open(path_test + 'result/' + result_file_name, 'w') as fw:
		fw.writelines(','.join(['"intersection_id"', '"tollgate_id"', '"time_window"', '"avg_travel_time"']) + '\n')
		for i in range(test_set.num):
			route = route_id[i]
			time_window_start, time_window_end = convert_to_time_window(time[i], data['interval'][i])
			avg_tt = predicted_Y[i]
			out_line = ','.join(['"' + route.split('-')[0] + '"', '"' + route.split('-')[1] + '"',
									'"[' + str(time_window_start) + ',' + str(time_window_end) + ')"',
									'"' + str(avg_tt) + '"']) + '\n'
			i += 1
	   		fw.writelines(out_line)
		'''t = 0
		for i in range(len(routes)):
			route = routes[i]
			route_time_windows = list(travel_times[route].keys())
			route_time_windows.sort()
			for j in range(len(route_time_windows)):
				time_window_start = route_time_windows[j]
				time_window_end = route_time_windows[j] + timedelta(minutes=20)
				avg_tt = predicted_Y[t]
				t += 1
				out_line = ','.join(['"' + route.split('-')[0] + '"', '"' + route.split('-')[1] + '"',
									'"[' + str(time_window_start) + ',' + str(time_window_end) + ')"',
									'"' + str(avg_tt) + '"']) + '\n'
	   			fw.writelines(out_line)
		'''		
			
def submit(model):
	#import ipdb
	#ipdb.set_trace()
	test_weather_file = 'weather (table 7)_test1'
	test_trajectory_file = 'trajectories(table 5)_test1'
	road_link_file = 'links(table 3)'
	intersection2tollgate_file = 'routes(table 4)'
	data_file = 'test_data'
	result_file = 'training_20min_avg_travel_time_3'
	route_id, time = construct_data(test_trajectory_file, test_weather_file, road_link_file, intersection2tollgate_file, data_file)
	test_set, _ = preprocess(data_file, 0.0, path_test, shuffle=False)
	test_set_ = test_set
	fe = FeatureExtractor(test_set_)
	test_X, test_Y = fe.extract_feature()
	Yp = model.predict(test_X)
	write_into_file(route_id, time, test_set, Yp, result_file)

if __name__ == '__main__':
	model = None
	submit(model)