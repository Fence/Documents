import os
import json
import argparse
import numpy as np
from regressor import Model
#from evalutor import LabelEvalutor
from preprocess import DataSet, preprocess
from FeatureExtractor import FeatureExtractor
from submission import submit
from HyperParameterTunning import HyperParameterTunning
from utils import pprint

path = '../data/dataSets/training/'
suffix = '.json'

def get_args():
	parser = argparse.ArgumentParser()
	parser.add_argument("--model", default="svm", help="designated model will be used to do regression")
	args = parser.parse_args()
	return args

def main():
	import ipdb
	ipdb.set_trace()
	args = get_args()
	train_set, dev_set = preprocess(rate=0.0)
	test_set, _ = preprocess(data_file='test_data', rate=0.0)
	hpt = HyperParameterTunning(args)
	hpt.tune_parameter([train_set, test_set])
	p = hpt.get_best_pamater()
	pprint(p)
	'''
	model = Model(args)
	train_set, dev_set = preprocess(rate=0.0)
	test_set, _ = preprocess(data_file='test_data', rate=0.0)
	fe = FeatureExtractor(train_set)
	X, Y = fe.extract_feature()
	model.train(X, Y)

	validation_fe = FeatureExtractor(test_set)
	validation_X, validation_Y = validation_fe.extract_feature()
	Yp = model.predict(validation_X)
	rate = np.absolute(1 - np.divide(validation_Y, Yp))
	mape = np.mean(rate)
	difference = validation_Y - Yp
	validation_Y_mean = np.mean(validation_Y)
	validation_Y_std = np.std(validation_Y) 
	Yp_mean = np.mean(Yp)
	Yp_std = np.std(Yp)
	print 'validation_Y_mean'
	print 'validation_Y_std'
	print 'Yp_mean'
	print 'Yp_std'
	print validation_Y_mean
	print validation_Y_std
	print Yp_mean
	print Yp_std
	observe = np.concatenate((np.expand_dims(validation_Y, -1), np.expand_dims(Yp, -1), np.expand_dims(difference ,-1)), -1)
	print 'observe'
	print observe[0:30]
	
	print 'validation_Y'
	print validation_Y.shape
	print validation_Y[0:10]
	print 'Yp'
	print Yp.shape
	print Yp[0:10]
	print 'difference'
	print difference[0:100]
	
	print 'mape'
	print mape
	
	submit(model)

	#validation_X, _ = extract_feature()
	#Yp = model.predict(X)
	#evalutor = Evaluator()
	'''
if __name__ == '__main__':
	main()