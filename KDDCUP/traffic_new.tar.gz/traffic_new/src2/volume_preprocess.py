import numpy as np
from datetime import datetime, timedelta
import json
import tqdm

file_suffix = '.csv'
path = '../data/dataSets/training/'


def read_volume_data(volume_file, weather_file, path=path):
	pass

def volume_preprocess():
	pass

if __name__ == '__main__':

	import ipdb
	ipdb.set_trace()
	
	weather_file = 'weather (table 7)_training_update'
	road_link_file = 'links(table 3)'
	intersection2tollgate_file = 'routes(table 4)'
	volume_file = 'volume(table 6)_training'
	data_file = 'test_data'